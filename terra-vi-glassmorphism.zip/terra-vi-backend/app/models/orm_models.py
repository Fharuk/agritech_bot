import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.database import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class FarmerSession(Base):
    __tablename__ = "farmer_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(36), unique=True, default=_uuid, index=True)
    crop: Mapped[str] = mapped_column(String(50))
    channel: Mapped[str] = mapped_column(String(20), default="web")
    language: Mapped[str] = mapped_column(String(10), default="en")   # en | ha | yo | ig
    state_ng: Mapped[str | None] = mapped_column(String(50), nullable=True)  # Nigerian state (for analytics)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    result: Mapped["DiagnosisResult"] = relationship(back_populates="session", uselist=False)


class DiagnosisResult(Base):
    __tablename__ = "diagnosis_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("farmer_sessions.session_id"), index=True
    )

    model_used: Mapped[str] = mapped_column(String(150))
    disease_slug: Mapped[str | None] = mapped_column(String(100), nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw_model_response: Mapped[str | None] = mapped_column(Text, nullable=True)

    treatment_found: Mapped[bool] = mapped_column(default=False)
    low_confidence: Mapped[bool] = mapped_column(default=False)

    # Phase 2 — severity scoring
    severity_score: Mapped[int | None] = mapped_column(Integer, nullable=True)   # 1–10 urgency
    photo_quality_score: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0.0–1.0

    inference_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    session: Mapped["FarmerSession"] = relationship(back_populates="result")
